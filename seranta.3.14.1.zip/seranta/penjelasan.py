# -*- coding: utf-8 -*-
"""
Penjelasan bahasa sederhana untuk setiap aturan dan setiap jenis temuan QC.

Dipakai laporan HTML (tool 1, 3, 4) agar setiap pembaca, termasuk yang bukan desainer, paham:
  * apa yang dicek,
  * mengapa itu penting di lapangan,
  * apa arti temuan ini untuk objek tersebut,
  * apa yang perlu dilakukan.

Teks sengaja netral (tanpa nama merek atau perusahaan). Angka batas diambil dari profil standar yang
dipakai saat QC dijalankan, bukan ditulis tetap di sini.

Part of Seranta - FTTH Design Assistant.
Copyright (C) 2026 Joseph Edward Timothy Siahaan. Licensed under GPL-3.0-or-later (see LICENSE).
"""

# ---------------------------------------------------------------------------------------------
# Tingkat temuan (bahasa awam)
# ---------------------------------------------------------------------------------------------
SEVERITY = {
    "ERROR": ("Wajib diperbaiki",
              "Desain melanggar batas tegas. Perbaiki sebelum desain dikirim, atau catat pengecualian yang disetujui."),
    "WARNING": ("Perlu ditinjau",
                "Belum tentu salah, tetapi di luar kebiasaan atau di atas batas anjuran. Periksa dan beri alasan bila dipertahankan."),
    "UNVERIFIED": ("Belum bisa dicek",
                   "Data pendukung tidak tersedia atau tidak terbaca. Ini BUKAN tanda lolos: lengkapi data lalu jalankan ulang."),
    "INFO": ("Catatan",
             "Petunjuk untuk efisiensi atau kerapian. Tidak wajib diubah."),
    "PASS": ("Lolos",
             "Aturan dijalankan dengan data lengkap dan tidak ada temuan."),
}

# ---------------------------------------------------------------------------------------------
# Penjelasan per aturan (tool 4 - QC APD Pasca-Desain)
#   cek     : apa yang diperiksa
#   alasan  : mengapa penting
#   tindakan: apa yang dilakukan bila ada temuan
# ---------------------------------------------------------------------------------------------
RULES = {
    "SERVED": dict(
        cek="Setiap homepass (HP), FAT dan FDT di hasil desain otomatis harus berstatus terlayani dan punya induk yang jelas.",
        alasan="HP yang tidak terlayani berarti rumah itu tidak mendapat port, padahal dihitung sebagai target. Jumlah HP terjual bisa meleset.",
        tindakan="Buka hasil desain otomatis, cari objek yang disebut, lalu hubungkan ke FAT/FDT terdekat atau jalankan ulang penugasan HP."),
    "FAT_COVERAGE": dict(
        cek="Setiap HP berada di dalam satu poligon FAT Coverage, dan poligon yang dipakai sama dengan FAT yang melayaninya.",
        alasan="Coverage adalah peta wilayah layanan. HP di luar coverage atau di coverage FAT lain membuat tim lapangan menarik kabel drop ke FAT yang salah.",
        tindakan="Perbarui poligon coverage atau pindahkan HP ke FAT yang wilayahnya mencakup rumah tersebut."),
    "CABLE_END": dict(
        cek="Ujung kabel distribusi harus berakhir di FAT (bukan menggantung), dan kabel loop tidak terlalu panjang.",
        alasan="Kabel yang berakhir tanpa perangkat adalah biaya material tanpa pelanggan, dan bisa jadi tanda jalur terputus.",
        tindakan="Potong kabel sampai FAT terakhir, atau tambahkan FAT bila memang ada HP di ujung jalur."),
    "MULTI_FDT": dict(
        cek="Hirarki FDT ke FAT benar, kapasitas FDT dan FAT tidak terlampaui, dan premises di ikon sama dengan jumlah HP.",
        alasan="Kapasitas berlebih berarti ada rumah yang tidak kebagian port splitter. Premises yang salah membuat BOM dan laporan penjualan tidak cocok.",
        tindakan="Pindahkan sebagian FAT ke FDT lain, tambah splitter sesuai batas, atau perbaiki angka premises pada ikon."),
    "FAT_HP_DISTANCE": dict(
        cek="Jarak dari FAT ke HP terjauh yang dilayaninya, diukur sepanjang jalur tiang bila tersedia.",
        alasan="Kabel drop yang terlalu panjang menambah redaman, biaya, dan risiko gangguan. Batas ini biasanya tertulis di kontrak desain.",
        tindakan="Geser FAT lebih ke tengah kelompok HP, atau pecah kelompok menjadi dua FAT."),
    "FAT_CODE": dict(
        cek="Kode FAT unik, berurutan tanpa lompatan, panjang kode seragam, dan awalan kode FAT sama dengan kode FDT induknya.",
        alasan="Kode adalah alamat perangkat di sistem inventori. Kode ganda atau acak membuat aktivasi pelanggan dan perbaikan gangguan salah alamat.",
        tindakan="Beri ulang nomor FAT sesuai urutan dari FDT, lalu samakan di KMZ, tabel kode dan hasil desain otomatis."),
    "FAT_ON_POLE": dict(
        cek="Titik FAT dan FDT tepat di atas titik tiang (tidak 'melayang').",
        alasan="Perangkat udara harus dipasang di tiang. Titik yang melayang membuat tim pemasang tidak tahu tiang mana yang dipakai.",
        tindakan="Seret titik perangkat ke titik tiang terdekat, atau tambahkan tiang bila memang belum ada."),
    "POLE_IDLE": dict(
        cek="Setiap tiang baru (NP) dilewati kabel distribusi atau feeder. Tiang existing (EP) dan tiang yang dilewati kabel "
            "feeder boleh tidak dilewati kabel distribusi. Tiang di seberang jalan (sampai 7 m dari garis kabel) dihitung dipakai.",
        alasan="Tiang baru yang tidak dipakai adalah biaya pemasangan dan izin tanpa manfaat.",
        tindakan="Buka koordinat (tikor) di keterangan temuan, lalu hapus tiang NP itu atau lewatkan jalur kabel melaluinya."),
    "SPAN_APD": dict(
        cek="Jarak antar tiang di sepanjang jalur kabel tidak melebihi batas tegas maupun batas regulasi daerah. Tiang di "
            "kiri-kanan jalan (sampai 7 m dari garis kabel, lebar jalur jalan sedang) dihitung sebagai tiang penopang, "
            "sehingga kabel yang menyeberang jalan tidak dianggap bentang panjang.",
        alasan="Bentang terlalu panjang membuat kabel melendut rendah di atas jalan dan sering ditolak saat perizinan.",
        tindakan="Sisipkan tiang di tengah bentang yang terlalu panjang."),
    "FAT_CENTER": dict(
        cek="Posisi FAT kira-kira di tengah kelompok HP-nya, dan HP tidak dilayani FAT yang jauh padahal ada FAT yang lebih dekat.",
        alasan="FAT di tengah membuat kabel drop rata-rata lebih pendek dan pekerjaan instalasi lebih cepat.",
        tindakan="Pertimbangkan menggeser FAT atau menukar kelompok HP. Ini saran efisiensi, bukan kesalahan."),
    "SLACK": dict(
        cek="Cadangan kabel (slack) dicatat secara berkala di sepanjang kabel.",
        alasan="Slack dipakai saat perbaikan atau relokasi tiang. Tanpa slack, kabel putus harus disambung dengan biaya lebih besar.",
        tindakan="Tambahkan keterangan slack pada kabel di jarak yang diminta profil."),
    "CROSSING": dict(
        cek="Kabel yang memotong rel kereta, jalan tol atau hambatan besar lain.",
        alasan="Penyeberangan seperti ini butuh izin khusus dan metode pemasangan khusus.",
        tindakan="Pastikan izin tersedia, atau ubah rute mengikuti penyeberangan yang sudah ada."),
    "FDT_COLO_NEW": dict(
        cek="FDT yang dipakai sama di paket Feeder dan Distribution (kode dan lokasi), dan status COLO/NEW-nya jelas.",
        alasan="Jika FDT di dua paket berbeda, kabel feeder bisa ditarik ke titik yang salah.",
        tindakan="Samakan kode dan koordinat FDT di kedua paket, lalu tandai statusnya (COLO memakai FDT yang ada, NEW memasang FDT baru)."),
    "BOM": dict(
        cek="Jumlah material di BOM sama dengan jumlah di desain: HP, FAT, FDT, tiang, closure dan panjang kabel (termasuk slack).",
        alasan="BOM yang tidak cocok menyebabkan kekurangan material di lapangan atau tagihan berlebih.",
        tindakan="Perbaiki BOM atau desain hingga selisihnya nol (atau dalam toleransi untuk kabel)."),
    "KMZ_APD": dict(
        cek="Struktur folder KMZ, ikon yang ikut tersimpan, warna dan keterangan kabel sesuai aturan penulisan KMZ.",
        alasan="KMZ adalah dokumen serah terima. Folder salah nama atau ikon hilang (tanda X) membuat pemeriksa kesulitan membaca desain.",
        tindakan="Ganti nama folder sesuai saran, simpan ulang KMZ dengan ikon tertanam, dan lengkapi keterangan kabel."),
    "QC01_KODE_FDT": dict(
        cek="Kode FDT sesuai format, tidak dipakai dua kali, tidak bentrok dengan FDT existing lain, kode FDT baru sudah tercatat di rekap kode, dan kelompok kodenya sama dengan kelompok FDT existing di sekitarnya (kandidat grouping).",
        alasan="Kode FDT dipakai sebagai kunci di seluruh dokumen. Kode ganda atau belum terdaftar membuat desain tidak bisa diaktivasi.",
        tindakan="Minta kode resmi dari pengelola rekap kode, lalu samakan di KMZ dan tabel kode."),
    "QC02_PREMISES_SPLITTER": dict(
        cek="Premises FDT sama dengan jumlah premises FAT di bawahnya; jumlah splitter sesuai batas; output FDT cukup untuk input FAT; jumlah splitter FAT sesuai jumlah HP; fiber/tube di Splice Plan cocok dengan tabel kode.",
        alasan="Ini memastikan setiap rumah benar-benar mendapat jalur serat dari FDT sampai FAT, dan dokumen sambungan (Splice Plan) sama dengan desain.",
        tindakan="Perbaiki angka premises/splitter di tabel kode, atau perbaiki Splice Plan agar fiber/tube dan jumlah splitter sama."),
    "QC03_PROPERTIES": dict(
        cek="Isi properties FDT/FAT di KMZ sama dengan tabel kode FDT-FAT (premises, splitter, koordinat, F/T); FDT COLO punya info cluster colo, FDT NEW tidak.",
        alasan="Properties di KMZ dibaca oleh tim inventori. Beda angka antara KMZ dan tabel membuat data aset tidak bisa dipercaya.",
        tindakan="Salin nilai yang benar dari tabel kode ke properties KMZ (atau sebaliknya), lalu simpan ulang."),
    "QC04_TIANG_REFERENSI": dict(
        cek="Tiang existing di desain berada dekat titik tiang existing di data referensi kota.",
        alasan="Tiang existing yang bergeser jauh kemungkinan salah gambar, sehingga perhitungan bentang dan izin sewa tiang ikut salah.",
        tindakan="Pindahkan tiang ke titik referensi, atau ubah menjadi tiang baru bila memang tidak ada tiang existing di situ."),
    "QC05_RASIO": dict(
        cek="Panjang kabel pancingan tidak melebihi persentase tertentu dari panjang kabel baru, dan jumlah closure 96 tidak melebihi persentase tertentu dari jumlah FAT AE (lingkup Distribution).",
        alasan="Rasio ini adalah indikator efisiensi desain. Rasio tinggi biasanya berarti rute berputar-putar atau sambungan berlebih.",
        tindakan="Sederhanakan rute pancingan atau kurangi closure dengan memindahkan titik percabangan."),
    "QC06_TIANG_PERANGKAT": dict(
        cek="FDT baru, FAT AE dan closure 96 baru berdiri tepat di tiang.",
        alasan="Perangkat udara tanpa tiang tidak bisa dipasang sesuai gambar.",
        tindakan="Letakkan perangkat di titik tiang terdekat atau tambahkan tiang baru."),
    "QC07_PANCINGAN": dict(
        cek="Kedua ujung kabel pancingan bertumpu pada tiang.",
        alasan="Pancingan yang tidak ditopang tiang tidak dapat dipasang dan membahayakan pengguna jalan.",
        tindakan="Geser ujung pancingan ke tiang terdekat atau tambahkan tiang penopang."),
}

# ---------------------------------------------------------------------------------------------
# Penjelasan per jenis temuan: (judul sederhana, arti, cara memperbaiki)
#   {obj} = kode/nama objek, {v} = nilai terukur, {t} = batas
# ---------------------------------------------------------------------------------------------
FINDINGS = {
    # --- served / coverage ---
    "HP_ID_DUPLICATE": ("ID homepass dipakai dua kali", "Satu ID homepass muncul lebih dari sekali, sehingga jumlah HP bisa terhitung ganda.",
                        "Hapus salah satu titik atau beri ID baru yang unik."),
    "SERVED_HP_NOT_SERVED": ("Rumah tidak terlayani", "HP {obj} tidak mendapat port FAT di hasil desain otomatis.",
                             "Hubungkan HP ke FAT terdekat yang masih punya port, lalu jalankan ulang penugasan."),
    "SERVED_HP_PARENT_UNKNOWN": ("Induk HP tidak ditemukan", "HP {obj} menunjuk ke perangkat yang tidak ada di data node.",
                                 "Periksa apakah FAT induknya terhapus; tugaskan ulang HP."),
    "SERVED_FAT_NOT_SERVED": ("FAT tidak tersambung ke FDT", "FAT {obj} tidak punya FDT induk, jadi seluruh rumah di bawahnya tidak dapat sinyal.",
                              "Sambungkan FAT ke FDT lewat kabel distribusi dan jalankan ulang desain."),
    "SERVED_CONNSTATUS_DIFFERENT": ("Status sambungan berbeda", "Status sambungan {obj} berbeda dari mayoritas perangkat.",
                                    "Cek tab hasil di aplikasi desain otomatis untuk objek ini."),
    "HP_OUTSIDE_FAT_COVERAGE": ("Rumah di luar wilayah FAT", "HP {obj} berada di luar semua poligon FAT Coverage ({v} m dari tepi terdekat).",
                                "Perluas poligon coverage FAT terdekat atau periksa koordinat rumah."),
    "FAT_COVERAGE_OVERLAP": ("Wilayah FAT tumpang tindih", "HP {obj} berada di lebih dari satu poligon coverage.",
                             "Rapikan batas poligon agar setiap rumah hanya masuk satu wilayah FAT."),
    "HP_WRONG_FAT_AREA": ("Rumah dilayani FAT tetangga", "HP {obj} dilayani satu FAT tetapi letaknya di wilayah FAT lain.",
                          "Pindahkan HP ke FAT pemilik wilayah, atau sesuaikan poligon coverage."),
    # --- ujung kabel / loop ---
    "LOOP_TERMINATION_CHECK": ("Ujung kabel di closure", "Kabel berakhir di closure, bukan di FAT.",
                               "Pastikan memang sengaja (titik sambung ke depan). Bila tidak, potong sampai FAT terakhir."),
    "CABLE_END_WITHOUT_FAT": ("Kabel berakhir tanpa FAT", "Ujung kabel {obj} tidak menempel ke FAT mana pun.",
                              "Potong kabel sampai FAT terakhir atau tambahkan FAT di ujungnya. Ekor kabel yang masih dalam batas "
                              "loop (100 m / 2 bentang) hanya perlu ditinjau dan dicatat alasannya."),
    "LOOP_LENGTH_OVER_100M": ("Kabel loop terlalu panjang", "Kabel loop {v} m, melebihi batas {t} m.",
                              "Pendekkan loop atau ubah rute agar tidak memutar."),
    "LOOP_SPAN_OVER_2": ("Kabel loop melewati terlalu banyak tiang", "Kabel loop melewati {v} bentang, batas {t}.",
                         "Pendekkan loop sampai batas bentang yang diizinkan."),
    # --- hirarki & kapasitas ---
    "FAT_PARENT_FDT_MISSING": ("FAT tanpa FDT induk", "Tidak ditemukan FDT induk untuk {obj}.",
                               "Pastikan FDT tergambar dan FAT tersambung kepadanya."),
    "FAT_MULTI_PARENT": ("FAT diklaim dua FDT", "FAT {obj} terhubung ke lebih dari satu FDT.",
                         "Pilih satu FDT induk dan putuskan sambungan yang lain."),
    "FAT_OVER_CAPACITY": ("FAT kelebihan rumah", "FAT {obj} melayani {v} HP, melebihi kapasitas {t} HP.",
                          "Pindahkan sebagian HP ke FAT tetangga atau tambah FAT baru."),
    "FAT_UNDER_MIN": ("FAT sepi pelanggan", "FAT {obj} hanya melayani {v} HP, di bawah minimum {t} HP.",
                      "Pertimbangkan menggabungkan dengan FAT tetangga. Boleh dipertahankan bila jaraknya tidak memungkinkan."),
    "FAT_PREMISES_MISMATCH": ("Premises FAT tidak cocok", "Angka premises pada FAT {obj} berbeda dari jumlah HP yang benar-benar dilayani.",
                              "Perbarui angka premises pada ikon FAT sesuai jumlah HP."),
    "FDT_CAPACITY_CHECK": ("FDT kelebihan rumah", "FDT {obj} melayani {v} HP, melebihi kapasitas {t} HP.",
                           "Pindahkan sebagian FAT ke FDT lain atau rencanakan FDT baru."),
    "FDT_SPLITTER_OVER": ("Splitter FDT berlebih", "FDT {obj} butuh {v} splitter, melebihi batas {t}.",
                          "Kurangi FAT di bawah FDT ini atau tambah FDT."),
    "FDT_PREMISES_MISMATCH": ("Premises FDT tidak cocok", "Premises pada ikon FDT {obj} ({v}) berbeda dari jumlah HP di bawahnya ({t}).",
                              "Perbarui premises ikon FDT."),
    "FDT_WITHOUT_FAT": ("FDT tanpa FAT", "FDT {obj} tidak punya FAT di bawahnya.",
                        "Periksa apakah FDT ini memang belum dipakai; hapus atau sambungkan FAT."),
    # --- jarak FAT ke HP ---
    "FAT_HP_OVER_150": ("Rumah terlalu jauh dari FAT", "HP terjauh di dalam FAT Coverage {obj} berjarak {v} m sepanjang jalur "
                        "kabel + drop, melebihi batas {t} m.",
                        "Geser FAT mendekati rumah terjauh atau pecah kelompok HP."),
    "FAT_HP_120_150": ("Rumah agak jauh dari FAT", "HP terjauh dari FAT {obj} berjarak {v} m (zona khusus).",
                       "Boleh dipertahankan hanya dengan justifikasi khusus; lebih baik geser FAT."),
    # --- kode ---
    "FAT_CODE_DUPLICATE": ("Kode FAT ganda", "Kode {obj} dipakai lebih dari satu FAT.", "Beri nomor ulang sehingga setiap FAT punya kode unik."),
    "FAT_LABEL_ORDER_INVALID": ("Nomor FAT melompat", "Ada nomor FAT yang hilang di urutan ({obj}).", "Beri nomor ulang FAT secara berurutan."),
    "FAT_ORDER_NOT_BY_DISTANCE": ("Urutan nomor FAT tidak mengikuti jarak", "FAT {obj} bernomor lebih kecil padahal lebih jauh dari FDT.",
                                  "Opsional: urutkan nomor FAT dari yang terdekat ke FDT."),
    "FDT_CODE_MISMATCH": ("Awalan kode FAT tidak sesuai FDT", "Awalan kode {obj} tidak sama dengan kode FDT mana pun.",
                          "Samakan awalan kode FAT dengan kode FDT induknya."),
    "FAT_LABEL_LENGTH": ("Panjang kode tidak seragam", "Panjang kode {obj} berbeda dari mayoritas.", "Periksa salah ketik pada kode."),
    # --- tiang ---
    "FAT_NOT_ON_POLE": ("FAT melayang", "FAT {obj} berjarak {v} m dari tiang terdekat (batas {t} m).", "Seret FAT ke titik tiang."),
    "FDT_NOT_ON_POLE": ("FDT melayang", "FDT {obj} berjarak {v} m dari tiang terdekat (batas {t} m).", "Seret FDT ke titik tiang."),
    "POLE_IDLE": ("Tiang baru (NP) tidak dilewati kabel", "Tiang NP {obj} berjarak {v} m dari kabel terdekat.",
                  "Hapus tiang NP yang tidak perlu, atau rutekan kabel melewatinya (koordinat ada di keterangan)."),
    "SPAN_OVER_MAX": ("Bentang tiang terlalu panjang", "Jarak tiang {obj} = {v} m, melebihi batas tegas {t} m.",
                      "Sisipkan tiang di tengah bentang."),
    "SPAN_OVER_REGULATION": ("Bentang di atas batas regulasi daerah", "Jarak tiang {obj} = {v} m, di atas batas regulasi {t} m.",
                             "Sisipkan tiang bila daerah tersebut menegakkan batas ini; bila tidak, cukup dicatat."),
    "SPAN_END_WITHOUT_POLE": ("Ujung kabel jauh dari tiang", "Ujung kabel berjarak {v} m dari tiang terakhir.",
                              "Tambahkan tiang di ujung kabel atau pendekkan kabel."),
    "FAT_NOT_CENTRAL": ("FAT kurang di tengah", "Rata-rata jarak HP ke FAT {obj} lebih jauh dibanding titik paling tengah.",
                        "Opsional: geser FAT ke tiang yang lebih di tengah kelompok."),
    "HP_GROUPING_REVIEW": ("Pengelompokan HP bisa lebih baik", "HP {obj} dilayani FAT yang lebih jauh padahal ada FAT yang lebih dekat.",
                           "Opsional: pindahkan HP ke FAT terdekat bila port masih tersedia."),
    "SLACK_GAP_OVER_PROFILE": ("Slack kabel baru terlalu jarang", "Kabel baru {obj}: jarak antar slack terpanjang {v} m, batas {t} m.",
                               "Tambahkan keterangan slack di tengah bentang kabel yang panjang."),
    "ROUTE_CROSSING_REVIEW": ("Kabel menyeberang rel/tol", "Kabel {obj} memotong hambatan besar.",
                              "Siapkan izin penyeberangan atau ubah rute."),
    # --- FDT dua paket ---
    "FDT_DATA_UNVERIFIED": ("Data FDT belum lengkap", "Data yang dibutuhkan untuk menguji FDT belum tersedia.",
                            "Lengkapi paket Feeder/Distribution lalu jalankan ulang."),
    "FDT_MISSING_IN_FEEDER": ("FDT tidak ada di paket Feeder", "FDT {obj} ada di Distribution tetapi tidak ada di Feeder.",
                              "Tambahkan FDT di paket Feeder dengan kode dan lokasi yang sama."),
    "FDT_MISSING_IN_DISTRIBUTION": ("FDT tidak ada di paket Distribution", "FDT {obj} ada di Feeder tetapi tidak ada di Distribution.",
                                    "Tambahkan FDT di paket Distribution."),
    "FDT_ID_MISMATCH": ("Kode FDT berbeda antar paket", "Lokasi FDT sama tetapi kodenya berbeda ({obj}).", "Samakan kode di kedua paket."),
    "FDT_LOCATION_MISMATCH": ("Lokasi FDT bergeser antar paket", "FDT {obj} bergeser {v} m antara dua paket (batas {t} m).",
                              "Samakan koordinat FDT di kedua paket."),
    "FDT_STATUS_UNKNOWN": ("Status COLO/NEW belum jelas", "Status FDT {obj} tidak bisa dipastikan dari data.",
                           "Isi status FDT (COLO/NEW) di parameter atau beri keterangan pada ikon."),
    "FDT_NEW_ROUTE_DISCONNECTED": ("FDT baru tidak tersambung jalur", "FDT/FAT {obj} tidak terhubung ke jalur kabel distribusi.",
                                   "Sambungkan perangkat ke kabel distribusi."),
    # --- BOM ---
    "BOM_CABLE_VARIANCE": ("Panjang kabel BOM berbeda", "Panjang kabel di BOM berbeda dari desain lebih dari toleransi.",
                           "Hitung ulang kabel (termasuk slack) dan perbarui BOM."),
    "BOM_HP_MISMATCH": ("Jumlah HP di BOM berbeda", "Jumlah HP di BOM tidak sama dengan desain.", "Samakan BOM dengan desain."),
    "BOM_FAT_MISMATCH": ("Jumlah FAT di BOM berbeda", "Jumlah FAT di BOM tidak sama dengan desain.", "Samakan BOM dengan desain."),
    "BOM_FDT_MISMATCH": ("Jumlah FDT di BOM berbeda", "Jumlah FDT di BOM tidak sama dengan desain.", "Samakan BOM dengan desain."),
    "BOM_POLE_MISMATCH": ("Jumlah tiang di BOM berbeda", "Jumlah tiang di BOM tidak sama dengan desain.", "Samakan BOM dengan desain."),
    "BOM_CLOSURE_MISMATCH": ("Jumlah closure di BOM berbeda", "Jumlah closure di BOM tidak sama dengan desain.", "Samakan BOM dengan desain."),
    # --- KMZ ---
    "KMZ_REQUIRED_LAYER_MISSING": ("Folder wajib tidak ada", "Folder {obj} tidak ditemukan di KMZ.", "Tambahkan folder tersebut sesuai struktur KMZ."),
    "KMZ_FOLDER_INVALID": ("Nama folder tidak baku", "Folder {obj} perlu diganti nama.", "Ganti nama folder sesuai saran di detail."),
    "KMZ_VISIBILITY": ("Folder sebaiknya disembunyikan", "Folder {obj} sebaiknya tidak dicentang saat KMZ final disimpan.", "Hilangkan centang lalu simpan ulang."),
    "KMZ_ICON_INVALID": ("Ikon hilang (tanda X)", "Ikon tidak ikut tersimpan di dalam KMZ sehingga tampil sebagai tanda X.",
                         "Simpan ulang KMZ dengan ikon tertanam (pilih format KMZ, bukan KML)."),
    "CABLE_COLOR_MISMATCH": ("Warna kabel salah", "Warna kabel {obj} tidak sesuai jumlah core-nya.", "Ganti warna garis sesuai tabel warna kabel."),
    "CABLE_LABEL_MISSING": ("Kabel tanpa keterangan", "Kabel tidak punya nama atau deskripsi.", "Isi keterangan kabel (core, panjang, status)."),
    "CABLE_LABEL_NO_STATUS": ("Keterangan kabel tanpa status", "Keterangan kabel {obj} tidak menyebut COLO atau NEW INFRA.", "Tambahkan status pada keterangan kabel."),
    "KMZ_COLO_MISSING_EXISTING": ("Folder Existing Cluster tidak ada", "Desain COLO tetapi KMZ tidak punya folder Existing Cluster.",
                                  "Tambahkan folder Existing Cluster berisi perangkat existing yang dipakai."),
    "FDT_COLO_LABEL_MISSING": ("FDT existing tanpa keterangan COLO", "FDT existing {obj} tidak diberi keterangan COLO.", "Tambahkan keterangan COLO pada ikon/label."),
    # --- QC-01..07 ---
    "FDT_CODE_DUPLICATE": ("Kode FDT ganda", "Kode {obj} dipakai lebih dari satu FDT.", "Pastikan setiap FDT memakai kode unik."),
    "FDT_CODE_FORMAT": ("Format kode FDT tidak baku", "Kode {obj} tidak mengikuti pola kode FDT.", "Perbaiki penulisan kode."),
    "FAT_CODE_PARENT_UNKNOWN": ("FAT tidak mengikuti kode FDT", "Awalan kode FAT {obj} tidak sama dengan FDT mana pun di desain.",
                                "Samakan awalan kode FAT dengan FDT induk."),
    "FDT_CODE_EXISTS_ELSEWHERE": ("Kode FDT sudah dipakai di lokasi lain", "Kode {obj} sudah dipakai FDT existing di tempat lain.",
                                  "Minta kode baru atau pastikan FDT ini memang FDT existing yang sama (COLO)."),
    "FDT_GROUP_MISMATCH": ("Kelompok kode FDT berbeda dengan sekitarnya", "Kode {obj} memakai kelompok area yang sudah dipakai di lokasi lain, padahal FDT existing di sekitarnya berkelompok lain.",
                           "Periksa kelompok kode area; bila memang salah, pakai kode kandidat yang disarankan di tabel grouping."),
    "FDT_GROUP_NEW": ("Kelompok kode FDT baru", "Kode {obj} membuka kelompok area baru yang belum dipakai FDT existing di sekitarnya.",
                      "Pastikan kelompok area baru ini memang disengaja dan sudah didaftarkan di rekap kode."),
    "FDT_NEW_NOT_IN_REKAP": ("Kode FDT baru belum terdaftar", "Kode FDT baru {obj} belum ada di rekap kode.", "Daftarkan kode ke pengelola rekap."),
    "FDT_PREMISES_NE_SUM_FAT": ("Premises FDT ≠ jumlah premises FAT", "Premises FDT {obj} = {v}, jumlah premises FAT di bawahnya = {t}.",
                                "Samakan premises FDT dengan jumlah premises FAT."),
    "FDT_SPLITTER_MISSING": ("Splitter FDT kosong", "Jumlah splitter FDT {obj} tidak terisi di tabel kode.", "Isi kolom splitter FDT."),
    "FDT_SPLITTER_OVER_MAX": ("Splitter FDT melebihi batas", "FDT {obj} memakai {v} splitter, batas {t}.", "Kurangi splitter atau pecah FDT."),
    "FDT_OUTPUT_SHORT": ("Output FDT kurang", "Output splitter FDT {obj} ({v}) lebih sedikit dari kebutuhan input FAT ({t}).",
                         "Tambah splitter FDT atau kurangi FAT di bawahnya."),
    "FAT_SPLITTER_TIER": ("Jumlah splitter FAT tidak sesuai HP", "FAT {obj} punya {v} HP, tetapi jumlah splitternya tidak sesuai aturan (1-8 HP = 1 splitter, 9-16 HP = 2 splitter).",
                          "Sesuaikan jumlah splitter FAT dengan jumlah HP."),
    "FAT_PREMISES_OVER_16": ("FAT lebih dari 16 HP", "FAT {obj} memiliki {v} premises.", "Pecah FAT menjadi dua."),
    "SPLICE_SHEET_MISSING": ("Splice Plan tidak memuat FAT ini", "Tidak ada sheet Splice Plan untuk FAT {obj}.", "Tambahkan FAT ke Splice Plan."),
    "SPLICE_SPLITTER_COUNT": ("Jumlah splitter beda dengan Splice Plan", "Tabel kode menyebut {t} splitter untuk {obj}, Splice Plan berisi {v}.",
                              "Samakan jumlah splitter di tabel kode dan Splice Plan (lihat juga jumlah HP FAT)."),
    "FIBER_TUBE_MISMATCH": ("Fiber/tube beda dengan Splice Plan", "Nomor fiber/tube {obj} di tabel kode berbeda dengan Splice Plan.",
                            "Ambil nomor fiber/tube dari sheet Route optique Splice Plan."),
    "FDT_COLO_INFO_MISSING": ("Info cluster COLO tidak ada", "FDT COLO {obj} tidak menyebut cluster asal FDT.", "Isi kolom COLO dengan cluster asal."),
    "FDT_NEW_HAS_COLO": ("FDT baru berisi kolom COLO", "FDT NEW {obj} mengisi kolom COLO, padahal FDT baru tidak memakai cluster lain.",
                         "Kosongkan kolom COLO untuk FDT baru."),
    "PROP_CODE_NOT_IN_TABLE": ("Perangkat tidak ada di tabel kode", "{obj} ada di KMZ tetapi tidak ada di tabel kode FDT-FAT.", "Tambahkan ke tabel kode."),
    "PROP_CODE_NOT_IN_KMZ": ("Kode di tabel tidak ada di KMZ", "{obj} ada di tabel kode tetapi tidak ditemukan di KMZ.", "Tambahkan perangkat ke KMZ atau hapus dari tabel."),
    "PROP_MISMATCH": ("Properties KMZ ≠ tabel kode", "Nilai properties {obj} di KMZ berbeda dengan tabel kode.", "Samakan nilai di KMZ dan tabel."),
    "AUTODESIGN_VS_TABLE": ("Hasil desain otomatis ≠ tabel kode", "Jumlah splitter/premises {obj} di hasil desain otomatis berbeda dengan tabel kode.",
                            "Periksa mana yang benar, lalu samakan."),
    "EXT_POLE_FAR_FROM_REF": ("Tiang existing tidak cocok dengan referensi", "Tiang existing {obj} berjarak {v} m dari tiang referensi terdekat (batas {t} m).",
                              "Pindahkan ke titik referensi, atau ubah statusnya menjadi tiang baru."),
    "PANCINGAN_RATIO_OVER": ("Kabel pancingan terlalu banyak", "Pancingan = {v}% dari panjang kabel baru (batas {t}%).", "Sederhanakan rute pancingan."),
    "CLOSURE_RATIO_OVER": ("Closure 96 terlalu banyak", "Closure 96 = {v}% dari jumlah FAT AE (batas {t}%).", "Kurangi closure atau gabungkan titik sambung."),
    "DEVICE_WITHOUT_POLE": ("Perangkat tidak di tiang", "{obj} berjarak {v} m dari tiang terdekat (batas {t} m).", "Letakkan perangkat tepat di tiang."),
    "PANCINGAN_END_NO_POLE": ("Ujung pancingan tanpa tiang", "Ujung pancingan {obj} berjarak {v} m dari tiang (batas {t} m).", "Tambahkan atau geser ke tiang."),
}

# Bila jenis temuan belum ada di daftar, tampilkan pesan teknis apa adanya.
DEFAULT_FINDING = ("Temuan", "{msg}", "Periksa objek di peta dan sesuaikan dengan aturan yang disebut.")


def finding_text(f):
    """(judul sederhana, arti, cara memperbaiki) untuk satu temuan (dict dari qc_core.finding)."""
    rid = f.get("rule_id", "")
    j, a, p = FINDINGS.get(rid, DEFAULT_FINDING)

    def num(x):
        if isinstance(x, float):
            return ("%.1f" % x).rstrip("0").rstrip(".")
        return "" if x is None else str(x)
    vals = {"obj": f.get("object_id") or f.get("object_type") or "objek", "v": num(f.get("value")),
            "t": num(f.get("threshold")), "msg": f.get("message", "")}
    try:
        a2 = a.format(**vals)
    except (KeyError, IndexError, ValueError):
        a2 = a
    if ("{v}" in a and not vals["v"]) or ("{t}" in a and not vals["t"]):
        a2 = f.get("message", a2)        # angka tidak tersedia -> pesan teknis lebih akurat
    if rid not in FINDINGS and f.get("recommendation"):
        p = f["recommendation"][0].upper() + f["recommendation"][1:]
    return j, a2, p


# ---------------------------------------------------------------------------------------------
# Tool 1 - Standar review survei (Strand)
# ---------------------------------------------------------------------------------------------
TOOL1_STD = {
    1: dict(cek="Setiap rumah (HP) cukup dekat ke tiang terdekat agar kabel drop bisa ditarik.",
            alasan="Rumah yang terlalu jauh dari tiang butuh tiang tambahan atau tidak bisa dilayani.",
            tindakan="Tambahkan tiang baru di dekat rumah tersebut, atau keluarkan rumah dari daftar HP."),
    2: dict(cek="Rumah tidak berada di cluster yang sudah dibangun (RFS), di funnel cluster lain, atau di dalam BOUNDARY "
                "cluster saudara (sub-cluster lain di wilayah yang sama, dibaca dari folder lain di folder induk).",
            alasan="Rumah yang sudah dilayani cluster lain akan dihitung dua kali (double tagging). Sub-cluster satu "
                   "wilayah biasanya berada di dalam satu Funnel induk, jadi hanya BOUNDARY KMZ yang memisahkannya.",
            tindakan="Hapus HP yang sudah menjadi milik cluster lain dari HPDB dan KMZ, dan rapikan BOUNDARY yang "
                     "tumpang tindih agar satu rumah hanya masuk satu cluster."),
    3: dict(cek="Nama kelurahan/kecamatan/kota di HPDB sama dengan data wilayah resmi (FINDIM).",
            alasan="Wilayah yang salah membuat laporan penjualan dan perizinan salah alamat.",
            tindakan="Perbaiki kolom wilayah HPDB mengikuti data wilayah resmi."),
    4: dict(cek="HPDB dan KMZ berisi rumah yang sama, satu rumah satu homepass, tanpa duplikat dan koordinat yang tertukar, "
                "termasuk duplikat dengan cluster saudara (rumah yang sama di HPDB/KMZ cluster lain di folder induk).",
            alasan="Duplikat membuat jumlah HP terlihat lebih besar dari kenyataan; duplikat lintas cluster membuat rumah "
                   "yang sama didesain dan ditagih dua kali.",
            tindakan="Hapus duplikat, lengkapi HP yang hilang di salah satu file, dan perbaiki koordinat. Untuk duplikat "
                     "lintas cluster, simpan rumah di satu cluster saja sesuai saran di temuan."),
    5: dict(cek="Rumah berada di dalam batas Funnel dan BOUNDARY cluster (rumah yang hanya beberapa meter di luar garis "
                "dicatat sebagai 'di tepi', karena GPS ponsel meleset 5-13 m).",
            alasan="Rumah di luar batas bukan bagian dari target cluster ini.",
            tindakan="Keluarkan HP di luar batas, atau ajukan perubahan boundary bila memang masuk area."),
    6: dict(cek="Status cluster di Funnel tidak reject/drop, dan HP/tiang belum ada di jaringan existing.",
            alasan="Mendesain cluster yang sudah ditolak atau sudah terbangun adalah pekerjaan sia-sia.",
            tindakan="Konfirmasi status cluster sebelum melanjutkan desain."),
    7: dict(cek="Ada FDT existing dalam radius yang diizinkan yang masih bisa dipakai bersama (COLO).",
            alasan="Memakai FDT existing jauh lebih murah dan cepat daripada memasang FDT baru.",
            tindakan="Pilih FDT existing dengan slot terbanyak, atau rencanakan FDT baru bila tidak ada."),
    8: dict(cek="Berita acara izin warga (BAKP) ada dan isiannya sesuai jumlah HP dan tiang.",
            alasan="Tanpa izin warga, pemasangan tiang dan kabel bisa ditolak di lapangan.",
            tindakan="Minta atau lengkapi BAKP ke vendor survei, lalu centang butir di daftar periksa."),
    9: dict(cek="Jarak antar tiang (sepanjang jalur kabel) tidak melebihi batas tegas maupun batas regulasi daerah.",
            alasan="Bentang terlalu panjang membuat kabel melendut dan sering ditolak saat izin.",
            tindakan="Sisipkan tiang baru di tengah bentang yang terlalu panjang."),
}

# Tool 1 - arti jenis temuan (cocokkan dengan awalan kode, urutan penting)
TOOL1_KIND = [
    # --- 3.9.5 (review Jambi Argenta, Tegal Karangmangu, Minahasa Tataaran Satu, Cianjur Nyalindung November 2026) ---
    ("HP_DI_AREA_TANPA_IZIN", "Rumah berada di dalam poligon yang ditandai vendor sebagai area tanpa izin / tanpa ruang "
     "(mis. 'TIDAK DAPAT IZIN', 'NO SPACE') di folder BOUNDARY KMZ.",
     "Keluarkan rumah itu dari HPDB dan KMZ, atau perbarui izin warga lalu hapus/ubah poligon larangannya."),
    ("TIANG_DI_AREA_TANPA_IZIN", "Tiang berada di dalam area yang ditandai tanpa izin / tanpa ruang.",
     "Pindahkan tiang keluar area itu, atau lengkapi izinnya."),
    ("WARN_JALUR_LEWAT_AREA_TANPA_IZIN", "Jalur kabel melintas area yang ditandai tanpa izin / tanpa ruang.",
     "Pastikan kabel boleh melintas (izin lintasan), atau geser jalur."),
    ("WARN_TSSR_ID_BEDA", "File TSSR di folder cluster memuat ID cluster lain: kemungkinan TSSR milik cluster lain yang "
     "ikut tersalin.", "Minta TSSR cluster ini dan cocokkan nama, ID, dan jumlah HP-nya."),
    ("WARN_TSSR_HP_BEDA", "Jumlah homepass di TSSR berbeda dengan jumlah baris HPDB.",
     "Samakan TSSR dengan HPDB (atau sebaliknya) sebelum review."),
    ("WARN_TSSR_DIPAKAI_BERSAMA", "File TSSR cluster ini identik dengan TSSR beberapa cluster lain: TSSR dibuat untuk wilayah "
     "induk (strand), sehingga jumlah HP dan nama cluster di dalamnya bukan milik cluster ini.",
     "Minta TSSR per cluster, atau lampiran yang merinci ID cluster dan jumlah HP setiap cluster di strand."),
    ("WARN_HPDB_RT_RW_TIDAK_SESUAI", "Kolom RT, RW/lingkungan atau CLUSTER_NAME di HPDB tidak sesuai wilayah rumah: nomornya "
     "di luar nama wilayah cluster (nama Funnel atau folder cluster), atau rumah itu dikelilingi rumah ber-RT/RW lain "
     "(mis. tertulis RT 24 padahal semua tetangganya RT 17). Biasanya salah ketik atau baris yang disalin dari wilayah lain.",
     "Cek lokasi rumah di peta/citra dan foto evidence. Bila rumah memang di wilayah cluster ini, perbaiki kolom RT/RW di "
     "HPDB; bila milik wilayah lain, keluarkan dari HPDB ini dan ajukan di cluster wilayahnya."),
    ("WARN_HPDB_CLUSTER_NAME_CAMPUR", "Satu HPDB memuat CLUSTER_NAME lebih dari satu cluster (mis. HP pindahan dari cluster "
     "saudara yang labelnya belum diganti, atau HP RT lain yang ikut masuk).",
     "Samakan CLUSTER_NAME sesuai cluster pemilik; bila HP memang milik cluster lain, keluarkan dari HPDB ini dan pastikan tidak "
     "terdaftar ganda."),
    ("WARN_BOUNDARY_TIDAK_VALID", "Poligon BOUNDARY di KMZ memotong dirinya sendiri (garis tepinya bersilang), sehingga luas, "
     "irisan dengan cluster lain dan uji 'HP di dalam BOUNDARY' tidak andal.",
     "Gambar ulang poligon dengan titik sudut berurutan mengikuti batas, tanpa garis bersilang."),
    ("INFO_HP_DI_BOUNDARY_SAUDARA_1PIC", "Rumah berada di dalam BOUNDARY cluster saudara yang didesain satu PIC / berdampingan "
     "dan satu funnel (atau satu wilayah induk). Boundary wilayah seperti ini boleh bertumpuk, jadi bukan alasan reject.",
     "Pastikan rumah hanya tercatat di HPDB satu cluster; bila tiang terdekatnya milik cluster saudara, pertimbangkan "
     "memindahkannya ke cluster itu."),
    ("INFO_BOUNDARY_BERIRISAN_1PIC", "BOUNDARY cluster ini bertumpuk dengan BOUNDARY cluster saudara dalam 1 PIC / berdampingan "
     "dan satu funnel (atau satu wilayah induk): diterima, bukan alasan reject. Yang tetap salah adalah boundary yang masuk "
     "funnel lain.", "Tidak wajib dirapikan; cukup pastikan rumah di area bertumpuk hanya ada di satu HPDB."),
    ("INFO_RENTANG_DITUMPU_TIANG_SAUDARA", "Rentang antartiang cluster ini panjang, tetapi jalurnya melewati tiang cluster saudara "
     "1 PIC / berdampingan yang menumpu kabel; diukur antar titik tumpu berurutan, rentang terpanjang masih dalam batas.",
     "Pastikan kabel memang diikat di tiang saudara itu (tiang bersama) dan dicatat sekali di BOQ."),
    ("INFO_TITIK_JALUR_DI_TIANG_SAUDARA", "Belokan, ujung, atau percabangan jalur cluster ini berada di tiang cluster saudara 1 PIC "
     "/ berdampingan (tiang itu dilewati jalur cluster saudara): titik itu ditumpu tiang, bukan tanpa tiang.",
     "Pastikan tiang itu dipasang treklam / tambat akhir sesuai sudut, dan tercatat sebagai tiang bersama."),
    # --- 3.13.0: integritas jalur ---
    ("JALUR_TANPA_TIANG", "Ada bagian garis jalur yang tidak ditumpu tiang lebih panjang dari batas bentang, diukur SEPANJANG "
     "JALUR: jalur tanpa satu pun tiang, ujung jalur yang jauh dari tiang terakhir, atau dua tiang yang dihubungkan lewat "
     "percabangan tanpa tiang. Kabel udara hanya bisa dipasang dari tiang ke tiang (bentang = jarak dua titik tumpu kabel "
     "berurutan), jadi bagian ini tidak bisa dibangun seperti digambar.",
     "Sisipkan tiang sepanjang bagian itu tiap <= batas bentang, pasang tiang tambat akhir di ujung dan tiang di "
     "percabangan; bila garisnya tidak dipakai, hapus garis jalurnya."),
    ("JALUR_TERPUTUS", "Bagian jalur ini tidak tersambung ke jaringan jalur cluster (celah lebih dari toleransi snap), "
     "sehingga tidak bisa dialiri serat dari FDT cluster.",
     "Sambungkan garis jalur di tiang ke jaringan cluster, atau jelaskan sumber seratnya (FDT/kabel lain)."),
    ("WARN_JALUR_TERPUTUS", "Bagian jalur tidak tersambung ke jaringan jalur cluster; cluster ini butuh lebih dari satu FDT "
     "sehingga bisa jadi bagian ini dilayani FDT lain.", "Pastikan setiap bagian jalur punya FDT/sumber serat."),
    ("WARN_JALUR_BERSILANG_TANPA_TIANG", "Dua garis jalur bersilang atau menempel tanpa simpul/tiang bersama. Bila itu "
     "percabangan, sambungan kabelnya tergantung di tengah bentang (sambungan harus di tiang); bila dua kabel terpisah, "
     "graf jalur tidak tersambung di titik itu.",
     "Pasang tiang di titik temu dan sambungkan garisnya di tiang, atau geser garis agar jelas dua kabel terpisah."),
    ("WARN_JALUR_BERTUMPUK", "Garis jalur digambar dua kali / bolak-balik di jalur yang sama, sehingga panjang kabel di BOQ "
     "terhitung ganda.", "Hapus garis rangkap (satu jalur fisik = satu garis) atau sebutkan bila memang dua kabel."),
    ("INFO_JALUR_TERSAMBUNG_LEWAT_SAUDARA", "Bagian jalur ini terpisah dari jalur cluster sendiri, tetapi tersambung ke jalur "
     "cluster saudara 1 PIC / berdampingan (satu jaringan): bukan alasan reject.",
     "Pastikan sambungan kabelnya di tiang dan tercatat di desain jaringan bersama."),
    ("WARN_TIANG_LUAR_BOUNDARY", "Tiang baru (NP) berdiri lebih dari toleransi di luar BOUNDARY cluster: izin warga (BAKP) "
     "dan survei berlaku untuk wilayah cluster, jadi lokasi tiang ini belum tentu tercakup izinnya.",
     "Pastikan izin mencakup lokasi itu, perluas boundary, atau pindahkan tiang ke cluster yang benar."),
    ("INFO_TIANG_EP_LUAR_BOUNDARY", "Tiang eksisting (EP) di luar BOUNDARY cluster: tidak ada pemasangan tiang baru.",
     "Cukup dicatat (sewa/attachment)."),
    ("WARN_JALUR_MELINTAS_TOL", "Jalur kabel memotong jalan tol menurut data jalan OpenStreetMap. Utilitas di ruang milik "
     "jalan tol wajib izin Direktur Jenderal Bina Marga atas rekomendasi teknis BPJT/BUJT (PP 23/2024 Pasal 71 dan 75; "
     "SE Dirjen Bina Marga 11/SE/Db/2017). Tidak ada angka ruang bebas resmi khusus tol: metode dan ruang bebas ditetapkan "
     "BUJT. Angka 5 m Permen PU 20/PRT/M/2010 tidak berlaku untuk tol (Pasal 3 mengecualikan jalan tol).",
     "Koordinasikan dengan BUJT ruas itu (portal SIP3 Rumija Tol Bina Marga) dan cantumkan izin serta metode crossing "
     "(udara, HDD/boring, atau menumpang jembatan/overpass) di desain; bila tidak memungkinkan, pindahkan jalur. Cek juga "
     "di citra: data OSM bisa belum lengkap atau bergeser."),
    ("WARN_JALUR_MELINTAS_REL", "Jalur kabel memotong rel kereta menurut data OpenStreetMap. Wajib izin Direktur Jenderal "
     "Perkeretaapian dengan izin prinsip penyelenggara prasarana (PM Perhubungan 36/2011 Pasal 11).",
     "Di atas rel: ruang tinggi >= 6,20 m dari kepala rel dan tiang >= 10 m dari as rel terluar (Pasal 7). Di bawah rel: "
     ">= 150 cm di bawah subgrade, penanaman mulai >= 10 m dari sisi terluar jalur (Pasal 8). Ajukan lewat portal DJKA "
     "Kemenhub, atau pindahkan jalur."),
    ("INFO_JALUR_MELINTAS_JALAN_BESAR", "Jalur kabel melintang jalan arteri/primer (jalan nasional/provinsi) menurut data "
     "OpenStreetMap.",
     "Kabel udara >= 5 m dari permukaan jalan tertinggi (Permen PU 20/PRT/M/2010 Pasal 12 ayat 6, tetap berlaku menurut "
     "Permen PU 6/2025) dan izin penyelenggara jalan sesuai status jalan (Pasal 5). Cek aturan daerah yang bisa lebih ketat."),
    ("WARN_JALUR_LUAR_BOUNDARY", "Sebagian jalur kabel di luar BOUNDARY cluster. Boleh bila jalur feeder ke FDT atau ke "
     "cluster lain; bila jalur distribusi, boundary atau jalurnya perlu dirapikan.",
     "Sebutkan fungsi jalur itu di desain, atau perluas boundary / pindahkan jalurnya."),
    ("INFO_TIANG_JALUR_DI_BOUNDARY_SAUDARA", "Tiang/jalur di luar BOUNDARY cluster ini tetapi di BOUNDARY cluster saudara 1 PIC "
     "(satu funnel): satu wilayah, bukan alasan reject.", "Catat sebagai tiang/jalur bersama."),
    ("COLO_TITIK_MASUK_TIDAK_DI_JALUR", "Tiang terdekat ke FDT colo (titik masuk kabel) tidak dilewati jalur cluster, "
     "sehingga kabel dari FDT tidak tersambung ke jaringan.", "Tarik jalur ke tiang itu atau tentukan titik masuk lain."),
    ("COLO_HP_TIDAK_TERJANGKAU_JALUR", "Sebagian HP dilayani bagian jalur yang tidak tersambung ke tiang titik masuk colo: "
     "serat dari FDT tidak sampai ke HP itu.", "Sambungkan bagian jalur itu atau rencanakan FDT/feeder lain untuknya."),
    ("INFO_HP_TERCOVER_TIANG_SAUDARA", "Rumah lebih dari batas jarak ke tiang cluster ini, tetapi ada tiang cluster saudara "
     "1 PIC / berdampingan (satu funnel) dalam batas jarak: drop bisa ditarik dari tiang itu, bukan alasan reject.",
     "Rencanakan drop/FAT dari tiang cluster saudara (catat sebagai tiang bersama) atau pindahkan rumah ke cluster itu."),
    ("INFO_NAMA_FILE_HP_BEDA", "Jumlah HP yang tertulis di nama berkas (KMZ/TSSR/BAKP) tidak sama dengan isi HPDB, biasanya "
     "karena nama berkas tidak diperbarui setelah revisi.", "Perbarui nama berkas agar sesuai jumlah HP terakhir."),
    ("INFO_TSSR_WILAYAH_BEDA", "Alamat di TSSR tidak menyebut kelurahan yang tertulis di HPDB.",
     "Cek nama kelurahan/kecamatan di TSSR; nama lama (sebelum pemekaran) juga perlu diperbarui."),
    ("WARN_HP_KOORDINAT_BEDA_FOTO", "Rumah tidak punya foto di dekat titiknya, tetapi ada foto evidence berlabel sama yang "
     "letaknya jauh: titik HP kemungkinan salah tempat.", "Pindahkan titik HP (HPDB dan KMZ) ke lokasi rumah di foto, atau "
     "perbaiki label fotonya."),
    ("INFO_FOTO_EVIDENCE_TANPA_HP", "Ada foto evidence rumah yang tidak punya pasangan HP di HPDB (tidak ada HP di dekatnya "
     "dan labelnya tidak ada di HPDB).", "Cek: rumah terlewat di HPDB, atau label foto salah."),
    ("WARN_HPDB_KARAKTER_TERSEMBUNYI", "Sel HPDB memuat karakter tak terlihat (mis. zero-width space dari aplikasi survei). "
     "Tidak tampak di Excel, tetapi membuat nomor rumah/alamat tidak cocok saat dicari atau dibandingkan.",
     "Hapus karakter itu (ketik ulang isi sel, atau Find & Replace karakter tersembunyi)."),
    ("INFO_BAKP_HASIL_SCAN", "BAKP berupa gambar hasil scan: tulisan tangan di dalamnya tidak dibaca otomatis oleh Seranta.",
     "Baca manual: Cluster ID & homepass, RT/RW di stempel, nominal kompensasi, centang verifikasi, dan tanda tangan."),
    # --- 3.6.0 (review Jambi, Tegal, Minahasa Oktober 2026) ---
    ("BOUNDARY_MEMUAT_CLUSTER_LAIN", "BOUNDARY di KMZ cluster ini memuat sebagian besar rumah cluster lain: BOUNDARY masih "
     "BOUNDARY induk/gabungan dari sebelum cluster dipecah.",
     "Gambar ulang BOUNDARY cluster ini hanya di sekitar rumah cluster ini."),
    ("INFO_HP_DI_BOUNDARY_INDUK_CLUSTER_LAIN", "Rumah cluster ini berada di dalam BOUNDARY cluster lain yang masih BOUNDARY "
     "induk/gabungan; kesalahannya ada di cluster lain itu.", "Cukup dicatat; perbaikan BOUNDARY dilakukan di cluster lain."),
    ("CLUSTER_LAIN_DIGABUNG", "Sekelompok rumah di HPDB/KMZ ini berada di Funnel milik cluster lain (sering ID-nya ada di "
     "FINDIM dan KMZ memuat sub-folder cluster itu): dua cluster digabung menjadi satu pengajuan.",
     "Pisahkan rumah-rumah itu ke cluster pemiliknya (HPDB, KMZ, evidence, BAKP sendiri), atau lampirkan persetujuan "
     "penggabungan."),
    ("INFO_HP_TEPI_FUNNEL_LAIN", "Rumah tepat di garis batas Funnel cluster ini dan Funnel cluster lain (hanya beberapa meter, "
     "masih dalam galat GPS ponsel).", "Cukup dicatat; tidak perlu dipindah."),
    ("WARN_TIANG_GANDA_LINTAS_CLUSTER", "Tiang yang sama (koordinat sama) tercatat di KMZ dua cluster: BOQ tiang terhitung dua "
     "kali.", "Tentukan cluster pemilik tiang; di cluster lain jadikan tiang existing/bersama."),
    ("INFO_SATU_PIC_DESAIN", "Cluster ini didesain sebagai satu jaringan / satu PIC dengan cluster lain (tiang bersama, kabel "
     "tersambung, BAKP sama, atau BOUNDARY berdampingan).",
     "Review sebagai satu paket: tiang bersama dihitung sekali, HP tidak ganda, BOUNDARY tidak saling masuk, satu rencana FDT."),
    ("WARN_TIANG_DUPLIKAT_KMZ", "Satu titik tiang digambar dua kali di KMZ (koordinat sama atau berjarak <= 1 m), kadang "
     "dengan tinggi berbeda.", "Hapus salinannya dan samakan tinggi tiang."),
    ("WARN_POLE_SHEET_BEDA_KMZ", "Sheet daftar tiang di HPDB tidak sama dengan tiang di KMZ (tinggi, posisi, atau baris ganda).",
     "Samakan sheet tiang dengan KMZ."),
    ("WARN_HP_TANPA_EVIDENCE", "Ada rumah di HPDB yang tidak punya foto survei (evidence) di laporan evidence maupun di KMZ.",
     "Lengkapi foto rumah tersebut."),
    ("WARN_CLUSTER_NAME_KOSONG", "Kolom CLUSTER_NAME di HPDB kosong.", "Isi nama cluster sesuai FINDIM / Funnel."),
    ("WARN_ADMIN_ID_CLUSTER_TIDAK_TERDAFTAR", "ID cluster belum ada di FINDIM, tetapi lebih baru dari semua ID di file FINDIM "
     "yang dipakai: kemungkinan cluster baru yang belum terdaftar.", "Minta FINDIM terbaru sebelum menolak karena ID."),
    ("HP_JAUH_DARI_TIANG", "Rumah terlalu jauh dari tiang terdekat.", "Tambahkan tiang di dekat rumah atau periksa koordinat rumah."),
    ("WARN_HP_JAUH_LEWAT_JALUR", "Garis lurus rumah ke tiang masih di bawah batas, tetapi bila kabel drop mengikuti jalur/"
     "akses (menyusuri jalan lalu masuk ke rumah) jaraknya melebihi batas.",
     "Cek akses di lapangan / street view; tambahkan tiang dekat rumah atau pastikan drop boleh lewat jalan pintas."),
    ("WARN_HP_AKSES_DALAM", "Rumah jauh dari semua jalur survei (mis. di belakang rumah lain): dari mana kabel drop masuk "
     "belum terlihat.", "Cek di lapangan atau street view: ada gang, atau izin melintas pekarangan tetangga? Gambar gang "
     "itu sebagai jalur bila ada."),
    ("HP_DUPLIKAT_LINTAS_CLUSTER", "Rumah yang sama juga tercatat di cluster saudara (koordinat sama, atau nomor rumah/nama "
     "sama dalam jarak galat GPS). Satu rumah akan dihitung dua kali bila kedua cluster didesain.",
     "Tentukan satu cluster pemilik (lihat saran: di dalam BOUNDARY siapa, tiang siapa lebih dekat), hapus baris HPDB dan "
     "titik KMZ dari cluster yang lain, lalu rapikan BOUNDARY."),
    ("WARN_HP_MUNGKIN_DUPLIKAT_LINTAS_CLUSTER", "HP cluster ini sangat mungkin rumah yang sama dengan HP cluster saudara: "
     "namanya hampir sama (salah ketik), titiknya berimpit dalam satu bangunan, atau label umumnya sama (mis. 'RUKO-1') "
     "pada jarak 5-25 m. Nomor unit seperti RUKO-1/TOKO 2 dipakai ulang di tiap deret, jadi perlu dicek.",
     "Cek di citra satelit; bila sama, simpan di satu cluster saja. Bila memang dua unit (ruko/kos), beri label yang jelas."),
    ("WARN_HP_LABEL_SAMA", "Dua HP memakai label survei yang sama tetapi berjauhan (25-50 m), atau label umum yang sama "
     "(mis. 'RUKO-1') pada 5-25 m: rumah yang sama dengan titik bergeser, atau rumah/unit berbeda berlabel sama.",
     "Cek citra satelit: bila rumah sama hapus salah satu; bila berbeda beri label unik (mis. nomor yang hilang di urutan)."),
    ("HP_DUPLIKAT_LABEL", "Dua baris HP di cluster ini memakai label survei (mis. ?327) atau nama/nomor rumah yang sama "
     "tetapi titiknya bergeser: satu rumah tercatat dua kali.",
     "Hapus salah satu baris HPDB dan titik KMZ; bila memang rumah berbeda, perbaiki label/nomor rumahnya."),
    ("INFO_HP_MUNGKIN_DUPLIKAT_LINTAS_CLUSTER", "HP cluster ini sangat dekat dengan HP cluster saudara dan nomor rumahnya "
     "kosong; mungkin rumah yang sama.", "Cek di citra satelit atau lapangan; bila sama, simpan di satu cluster saja."),
    ("HP_DI_BOUNDARY_CLUSTER_LAIN", "Rumah cluster ini berada jauh di dalam BOUNDARY cluster saudara (lebih dari toleransi "
     "GPS), sehingga dua cluster sama-sama mengklaim wilayah rumah itu.",
     "Tentukan cluster pemilik; keluarkan HP dari cluster yang bukan pemilik, atau perbaiki garis BOUNDARY."),
    ("INFO_HP_TEPI_BOUNDARY_CLUSTER_LAIN", "Rumah hanya beberapa meter di dalam tepi BOUNDARY cluster saudara (masih dalam "
     "toleransi GPS ponsel).", "Cukup dicatat; bila mau rapi, geser garis BOUNDARY bersama."),
    ("WARN_BOUNDARY_BERIRISAN_CLUSTER_LAIN", "BOUNDARY cluster ini tumpang tindih dengan BOUNDARY cluster saudara dan di "
     "irisan itu ada rumah.", "Gambar ulang garis batas bersama sehingga tidak ada rumah yang masuk dua BOUNDARY."),
    ("INFO_BOUNDARY_BERIRISAN_CLUSTER_LAIN", "Irisan tipis antara BOUNDARY cluster ini dan cluster saudara, tanpa rumah di "
     "dalamnya.", "Cukup dicatat (garis batas digambar tangan)."),
    ("WARN_ID_CLUSTER_GANDA", "ID cluster yang sama dipakai di file dua cluster berbeda (sering karena nama file disalin).",
     "Pastikan nama file HPDB, KMZ dan BAKP memakai ID cluster masing-masing."),
    ("INFO_ID_CLUSTER_SAMA_DI_CLUSTER_LAIN", "ID cluster ini juga muncul di nama file/dokumen cluster lain.",
     "Cek apakah itu ID induk Funnel yang dipakai bersama; bila bukan, perbaiki nama file cluster lain."),
    ("HP_DI_RFS_DONE", "Rumah berada di cluster yang sudah terbangun.", "Keluarkan dari HPDB/KMZ cluster ini."),
    ("HP_DI_RFS_EXT", "Rumah berada di wilayah perluasan cluster lain.", "Koordinasikan dengan pemilik cluster; biasanya dikeluarkan."),
    ("HP_DI_FUNNEL_LAIN", "Rumah masuk funnel cluster lain.", "Keluarkan dari cluster ini atau koordinasikan batas funnel."),
    ("ADMIN_", "Nama wilayah di HPDB berbeda dengan data wilayah resmi.", "Perbaiki kolom wilayah di HPDB."),
    ("HP_DUPLIKAT_KOORDINAT", "Dua atau lebih baris HPDB memakai koordinat yang sama (satu rumah tercatat lebih dari sekali). "
     "Akibatnya baris ganda juga tidak punya pasangan titik di KMZ; itu sudah dihitung di temuan ini.",
     "Bila satu rumah: hapus baris ganda dari HPDB. Bila memang rumah berbeda (bersebelahan/bertingkat): perbaiki koordinat "
     "baris itu ke rumahnya sendiri dan tambahkan titiknya di KMZ."),
    ("HP_DUPLIKAT_ID", "Dua atau lebih HP memakai ID operator yang sama.", "Beri ID unik atau hapus duplikat."),
    ("HP_HPDB_TIDAK_ADA_DI_KMZ", "HP ada di HPDB tetapi tidak tergambar di KMZ.", "Tambahkan titik di KMZ atau hapus dari HPDB."),
    ("HP_BERGESER", "Rumah yang sama (nomor rumah HPDB = nama titik KMZ) tetapi koordinatnya berbeda lebih dari toleransi.",
     "Samakan koordinat HPDB dengan titik survei KMZ (atau sebaliknya bila survei yang salah)."),
    ("HP_KMZ_TIDAK_ADA_DI_HPDB", "HP tergambar di KMZ tetapi tidak ada di HPDB.", "Tambahkan baris di HPDB atau hapus titik di KMZ."),
    ("LAT_LONG_TERTUKAR", "Kolom latitude dan longitude tampaknya tertukar.", "Tukar nilai kedua kolom pada baris tersebut."),
    ("HP_LUAR_FUNNEL", "Rumah di luar batas Funnel.", "Keluarkan HP atau ajukan perubahan batas."),
    ("HP_LUAR_BOUNDARY", "Rumah jelas di luar BOUNDARY KMZ (lebih jauh dari toleransi GPS).",
     "Pastikan rumah memang masuk cluster: bila ya, lebarkan BOUNDARY; bila tidak, keluarkan HP."),
    ("FUNNEL_SENDIRI_REJECT", "Cluster ini berstatus reject/drop di Funnel.", "Konfirmasi status sebelum desain dilanjutkan."),
    ("INFO_HP_MUNGKIN_DI_DESIGN_LITE", "Rumah 2-5 m dari HP jaringan existing, mungkin rumah yang sama.",
     "Cek nomor rumah/alamat; bila sama, keluarkan HP (double tagging)."),
    ("INFO_TIANG_BARU_DEKAT_EXISTING", "Tiang baru beberapa meter dari tiang jaringan existing.",
     "Cek di lapangan: bila tiangnya sama, jadikan tiang existing."),
    ("HP_SUDAH_ADA_DI_DESIGN_LITE", "Rumah sudah tercatat di jaringan existing (double tagging).", "Keluarkan HP dari cluster ini."),
    ("TIANG_BARU_SUDAH_ADA", "Tiang baru ternyata sudah ada di jaringan existing.", "Ubah menjadi tiang existing."),
    ("COLO_", "Catatan kemungkinan COLO FDT existing.", "Bandingkan pilihan FDT di tabel colo."),
    ("RENTANG_NP_NP", "Jarak antar tiang baru melebihi batas.", "Sisipkan tiang baru di tengah."),
    ("RENTANG_NP_EP", "Jarak tiang baru ke tiang existing melebihi batas.", "Geser tiang baru atau sisipkan tiang."),
    ("WARN_BAKP_ID_METADATA_BEDA", "Judul/subjek file PDF BAKP (nama dokumen di aplikasi scan) memuat ID cluster lain: "
     "kemungkinan BAKP milik cluster lain ikut terlampir.", "Buka BAKP dan cocokkan Cluster ID & jumlah homepass dengan "
     "cluster ini; minta BAKP yang benar bila berbeda."),
    ("BAKP_", "Isian BAKP perlu dicek.", "Bandingkan dengan nilai seharusnya di daftar periksa BAKP."),
    ("INFO_BAKP_", "Catatan BAKP.", "Tidak wajib diubah."),
    ("UNV_BAKP", "BAKP belum dapat diverifikasi otomatis.", "Periksa BAKP secara manual."),
    ("TIANG_NGANGGUR", "Tiang baru (NP) survei tidak dilewati jalur kabel.", "Buka koordinat di keterangan; hapus tiang NP "
     "bila tidak dipakai, atau lewatkan jalur bila memang dibutuhkan."),
    ("INFO_TIANG_EP_NGANGGUR", "Tiang existing (EP) tidak dilewati jalur kabel. Ini diperbolehkan.", "Tidak perlu tindakan."),
    ("UJUNG_JALUR_TANPA_TIANG", "Jalur berakhir tanpa tiang untuk menambat kabel (mulai 3.13.0 juga alasan reject di "
     "remarks; keterangan memuat panjang kabel sepanjang jalur dari tiang terakhir).", "Tambahkan tiang di ujung jalur."),
    ("WARN_BELOKAN_TANPA_TIANG", "Belokan tajam tanpa tiang (kabel butuh tiang tambat di belokan).", "Tambahkan tiang di titik belokan."),
    ("WARN_SIMPANG_TANPA_TIANG", "Percabangan jalur tanpa tiang: sambungan kabel tergantung di bentang (mulai 3.13.0 alasan "
     "reject; sambungan/splice closure dipasang di tiang).", "Tambahkan tiang di percabangan."),
    ("INFO_BELOKAN_KECIL_TANPA_TIANG", "Belokan kecil tanpa tiang.", "Opsional: pertimbangkan tiang sudut."),
    ("WARN_RENTANG_REGULASI", "Bentang di atas batas regulasi daerah.", "Sisipkan tiang bila daerah menegakkan batas ini."),
    ("INFO_RENTANG_REGULASI", "Bentang di atas batas regulasi daerah (catatan).", "Cukup dicatat."),
    ("INFO_HP_TEPI_BOUNDARY", "Rumah beberapa meter di luar garis BOUNDARY, masih dalam toleransi GPS ponsel.",
     "Tidak perlu dikeluarkan; bila mau rapi, lebarkan sedikit poligon BOUNDARY."),
    ("INFO_HP_TEPI_FUNNEL", "Rumah tepat di tepi luar Funnel (masih dalam toleransi GPS).", "Cukup dicatat."),
    ("INFO_HP_ALAMAT_SAMA", "Beberapa HP memakai alamat lengkap yang sama.", "Periksa apakah memang rumah berbeda (mis. kos/ruko)."),
    ("INFO_HP_MUNGKIN_DUPLIKAT", "Dua HP sangat berdekatan, mungkin rumah yang sama.", "Periksa di lapangan atau citra satelit."),
    ("INFO_KABEL_RENDAH", "Kabel di tengah bentang mungkin terlalu rendah di atas jalan.", "Pakai tiang lebih tinggi atau perpendek bentang."),
    ("INFO_TIANG_BISA_DIHAPUS", "Tiang baru di jalan lurus yang bisa dihapus tanpa melanggar batas bentang.", "Opsional: hapus untuk hemat biaya."),
    ("INFO_UJUNG_JALUR_TANPA_HP", "Ujung jalur tidak melayani rumah mana pun.", "Opsional: pendekkan jalur."),
]


def tool1_kind_text(kind):
    for pre, arti, aksi in TOOL1_KIND:
        if kind.startswith(pre):
            return arti, aksi
    return "", ""


# ---------------------------------------------------------------------------------------------
# Tool 2 - Alokasi FDT/FAT: istilah
# ---------------------------------------------------------------------------------------------
TOOL3_TERMS = [
    ("FAT minimum", "Jumlah FAT paling sedikit agar semua rumah kebagian port: jumlah HP dibagi kapasitas satu FAT, dibulatkan ke atas."),
    ("FAT estimasi", "Jumlah FAT bila rumah dikelompokkan sepanjang jalur kabel dengan batas jarak HP ke FAT. Biasanya sedikit di atas FAT minimum."),
    ("Slot FDT", "Sisa kapasitas FDT existing (dalam satuan FAT) yang masih bisa dipakai cluster ini."),
    ("COLO", "Memakai FDT yang sudah ada milik cluster lain. Lebih murah dan cepat daripada memasang FDT baru."),
    ("Link budget", "Perkiraan total redaman sinyal dari pusat ke rumah. Harus di bawah batas kelas optik agar layanan stabil."),
]


# Nama pendek untuk jalur aturan (kepala laporan)
SHORT = {
    "SERVED": "Terlayani", "FAT_COVERAGE": "Coverage", "CABLE_END": "Ujung kabel", "MULTI_FDT": "Kapasitas",
    "FAT_HP_DISTANCE": "Jarak HP", "FAT_CODE": "Kode FAT", "FAT_ON_POLE": "FAT di tiang", "POLE_IDLE": "Tiang nganggur",
    "SPAN_APD": "Bentang", "FAT_CENTER": "FAT sentral", "SLACK": "Slack", "CROSSING": "Rel/tol",
    "FDT_COLO_NEW": "FDT 2 paket", "BOM": "BOM", "KMZ_APD": "KMZ", "QC01_KODE_FDT": "Kode FDT",
    "QC02_PREMISES_SPLITTER": "Premises", "QC03_PROPERTIES": "Properties", "QC04_TIANG_REFERENSI": "Tiang ref.",
    "QC05_RASIO": "Rasio", "QC06_TIANG_PERANGKAT": "Perangkat", "QC07_PANCINGAN": "Pancingan",
}
